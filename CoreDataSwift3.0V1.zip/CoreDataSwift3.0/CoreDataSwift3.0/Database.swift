 //
//  Database.swift
 //  CoreDataSwift3.0//
 //  Created by AdminiMAC on 13/12/16.
 //  Copyright © 2016 AdminiMAC. All rights reserved.
 //

import UIKit
import CoreData

class Database: NSObject {
  
    // MARK: - sharedInstance

    static let sharedInstance: Database = {
        let instance = Database()
        // setup code
        return instance
    }()
    
    
    // MARK: - functionl methods

    func saveData () {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
//        return appDelegate.persistentContainer.viewContext
        appDelegate.saveContext()
    }
    
    func getContext () -> NSManagedObjectContext {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        return appDelegate.persistentContainer.viewContext
    }
    
    
    // MARK: - coredata operation methods

    func setData(entity: String , Data : NSDictionary) -> Bool{
        var flag = false
        
        let context = getContext()
        let entity =  NSEntityDescription.entity(forEntityName: entity, in: context)
        
        let data = NSManagedObject(entity: entity!, insertInto: context)
        
        data.setValue("joyye", forKey: "name")
        
        do {
            try context.save()
            print("Success")
            flag = true
        } catch let error as NSError  {
            flag =  false
            
            print("Could not save \(error), \(error.userInfo)")
        } catch {
            
        }
        return flag
    }
    
    
    func getAllData(entity: String) -> NSMutableDictionary {
        let dataDict : NSMutableDictionary = [:]

        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: entity)
        
        do {
            let results = try getContext().fetch(fetchRequest)
            
            for item in results as! [NSManagedObject] {
                dataDict.setValue("\(item.value(forKey: "name")!)", forKey: "name")
               // print("\(item.value(forKey: "name")!)")
            }
        } catch {
            print("Error with request: \(error)")
        }
        
        return dataDict as NSMutableDictionary
    }
    
    
    func deleteAllData(entity: String) -> Bool
    {
        
        var flag = true
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: entity)
        do {
            let results = try getContext().fetch(request)
            for item in results {
//                print(" Deleted... \(address)")
                getContext().delete(item as! NSManagedObject)
                flag = true
            }
            
        } catch let error {
            flag = false
            print(error.localizedDescription)
        }
        
        return flag
    }

    func updateData(entity: String, key: String, value: String) -> Bool
    {
        
        var flag = true
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: entity)
        do {
            let results = try getContext().fetch(request)
            for item in results {
                (item as AnyObject).setValue(value, forKey: key)
                saveData()
                flag = true
            }
            
        } catch let error {
            flag = false
            print(error.localizedDescription)
        }
        
        return flag
    }
    


    
 }
