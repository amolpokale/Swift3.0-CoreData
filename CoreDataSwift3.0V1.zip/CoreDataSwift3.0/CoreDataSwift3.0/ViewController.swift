//
//  ViewController.swift
//  CoreDataSwift3.0
//
//  Created by AdminiMAC on 13/12/16.
//  Copyright © 2016 AdminiMAC. All rights reserved.
//

import UIKit
class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        let dataDict = ["name":"Joyye"]
        
        //Set data
        var result = Database.sharedInstance.setData(entity: "User", Data: dataDict as NSDictionary)
        print(result)
        //get Data
       var resultDict  =  Database.sharedInstance.getAllData(entity: "User")
        
        print(resultDict)
        //dele
        
       result = Database.sharedInstance.updateData(entity: "User", key: "name", value: "barny")
        
        print(result)
        resultDict  =  Database.sharedInstance.getAllData(entity: "User")
        
        print(resultDict)
        
        print(Database.sharedInstance.deleteAllData(entity: "User"))

        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}

